<?php require "includes/conn.php" ?>
<?php
    $title = $specs = $mrp = $price = $color = $storage = $image = "";

    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $title = $_POST['title'];
        
    $query = "INSERT INTO `categories`(`title`) VALUES ('$title')";
    
    

    if(mysqli_query($conn, $query)){
        echo "success";
        // header("Location: ../products.php");
    }
    }else{
        echo "error";
    }

?>