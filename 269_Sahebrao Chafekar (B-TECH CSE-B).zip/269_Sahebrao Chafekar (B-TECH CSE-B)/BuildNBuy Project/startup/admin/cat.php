<?php

require 'includes/conn.php';

session_start();

if (!isset($_SESSION['admin_email'])) {
    echo "<script> location.href='/plantecom/admin/login.php'; </script>";
    exit();
}
require "includes/header.php";

?>


<div class="mainContainer">
    <?php require "includes/sidebar.php" ?>


    <div class="allContainer">
        <div class="container jumbotron jumbotron-fluid col-md-6 bg-light my-4 p-4 text-center">
            <div class="container">
                <h1 class="display-4">Add Category</h1>
            </div>
        </div>

        <div class="container col-md-6 my-4">
            <form class="row g-3" id="f"  action="addcat.php" method="POST" >
                <div class="col-md-6">
                    <label for="title" class="form-label">Category Name</label>
                    <input type="text" name="title" required class="form-control" id="title">
                </div>
                
                <div class="col-12">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script>
    $('#f').submit(function(e) {
    e.preventDefault(); // Prevent default form submission

        // Unbind the submit handler before triggering the submit
        // $(this).unbind('submit').submit();
        let formData = new FormData(this);

        // Submit the form via AJAX
        $.ajax({
            url: $(this).attr('action'), // Form action URL
            type: $(this).attr('method'), // Form method (POST)
            data: formData, // FormData object
            processData: false, // Required for FormData
            contentType: false, // Required for FormData
            success: function(response) {
                // Alert on successful submission
                alert('Category Added successfully!');
                // Optional: Reset the form fields
                $('#f')[0].reset();
            },
            error: function() {
                alert('An error occurred while submitting the form.');
            }
        });
    
});

</script>
</body>

</html>