<footer class="footer_part">
   
    <div class="copyright_part">
        <div class="container">
            <div class="row" >
                <div class="col-12" >
                    <div class="copyright_text" style="text-align: center;">
                        <p style="text-align: center;">
                            Copyright &copy;
                            <script>
                                document.write(new Date().getFullYear());
                            </script>
                            All rights reserved 
                        </p>
                    </div>
                </div>
              
            </div>
        </div>
    </div>

</footer>


