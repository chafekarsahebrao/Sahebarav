<?php
require "../includes/conn.php";
session_start();

$email = $_POST['email'];
$email = mysqli_real_escape_string($con, $email);

$pass = $_POST['password'];
$pass = mysqli_real_escape_string($con, $pass);
$pass = md5($pass);

$first = $_POST['fname'];
$first = mysqli_real_escape_string($con, $first);

$last = $_POST['lname'];
$last = mysqli_real_escape_string($con, $last);

$mobile = $_POST['mobile'];
$mobile = mysqli_real_escape_string($con, $mobile);

$age = $_POST['age'];
$age = mysqli_real_escape_string($con, $mobile);


$education = $_POST['education'];
$education = mysqli_real_escape_string($con, $education);

$language = $_POST['language'];
$language = mysqli_real_escape_string($con, $language);

$experience = $_POST['experience'];
$experience = mysqli_real_escape_string($con, $experience);

// $resume = $_FILE['resume'];
// $resume = mysqli_real_escape_string($con, $resume);


$query = "SELECT * from users where email='$email' or mobile='$mobile'";
$result = mysqli_query($con, $query);
$num = mysqli_num_rows($result);
if ($num != 0) {

    $m = "Email Or Mobile Already Exists";
    echo $m;
} else {
    // $quer = "INSERT INTO users(email_id,first_name,last_name,password) values('$email','$first','$last','$pass')";
    
    
    
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_FILES['resume']) && $_FILES['resume']['error'] == 0) 
    {
        $uploadDir = '../uploads/';
        $originalName = $_FILES['resume']['name'];
        $fileTmpPath = $_FILES['resume']['tmp_name'];

        // Get the file extension
        $fileExtension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

        // Generate a unique name
        $uniqueName = uniqid('resume_', true) . '.' . $fileExtension;
        $targetFile = $uploadDir . $uniqueName;

        // Optional: check file type, size, etc.
        $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
        $allowedTypes = ['pdf'];

        if (!in_array($fileType, $allowedTypes)) {
            echo "PDF files are allowed.";
        } else {
            if (move_uploaded_file($_FILES['resume']['tmp_name'], $targetFile)) {
                // echo $targetFile;
                $quer = "INSERT INTO `users`(`first_name`, `last_name`, `mobile`, `email`, `password`,`age`, `education`, `language`, `resume`, `experience`) VALUES ('$first','$last','$mobile','$email','$pass','$age','$education','$language','$uniqueName','$experience')";
    
                mysqli_query($con, $quer);
                $user_id = mysqli_insert_id($con);
                $_SESSION['email'] = $email;
                $_SESSION['user_id'] = $user_id;
                echo "success";
                
            } else {
                echo "There was an error uploading your file.";
            }
        }
    } else {
        echo "No file uploaded or upload error.";
    }
    
    
    
   
}
}
